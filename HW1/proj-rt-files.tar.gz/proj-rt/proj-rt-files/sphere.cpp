#include "sphere.h"
#include "ray.h"

// Determine if the ray intersects with the sphere
void Sphere::Intersection(const Ray& ray, std::vector<Hit>& hits) const
{
    TODO;
}

vec3 Sphere::Normal(const vec3& point) const
{
    vec3 normal;
    TODO; // compute the normal direction
    return normal;
}

// set this->bounding_box so that it contains the sphere as tightly as possible.
void Sphere::Update_Bounding_Box()
{
    TODO;
    infinite_box=false;
}

