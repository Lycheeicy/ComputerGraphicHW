#include "hit.h"
#include "object.h"

vec3 Hit::Normal() const
{
    TODO;
    return {};
}
